# مركز المذاكرة (Study Center)

موقع مذاكرة ثابت (ملف HTML واحد) يضم: بنك الشبكات، IT Essentials، التقييمات الذاتية.
لا يحتاج إلى خادم أو بناء.

## التشغيل محليًا
افتح `index.html` في المتصفح.

## النشر على GitHub Pages
1. ارفع الملفات إلى مستودع جديد.
2. Settings ← Pages ← Source: `Deploy from a branch` ← Branch: `main` / `(root)`.
3. سيظهر الموقع على `https://USERNAME.github.io/REPO/`.
